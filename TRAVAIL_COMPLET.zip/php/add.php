<html>
<head>
	<title>Add Data</title>
</head>

<body>
	<h2>Add Data</h2>
	<p>
		<a href="index.php">Home</a>
	</p>

	<form action="addAction.php" method="post" name="add">
		<table width="25%" border="0">
			<tr> 
				<td>Nom</td>
				<td><input type="text" name="nom"></td>
			</tr>
			<tr> 
				<td>Postnom</td>
				<td><input type="text" name="postnom"></td>
			</tr>
			<tr> 
				<td>Prenom</td>
				<td><input type="text" name="prenom"></td>
			</tr>
			<tr> 
				<td>Promotion</td>
				<td><input type="text" name="promotion"></td>
			</tr>
			<tr> 
				<td>Matricule</td>
				<td><input type="text" name="matricule"></td>
			</tr>
			<tr> 
				<td>Age</td>
				<td><input type="text" name="age"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr> 
				<td>Genre</td>
				<td><input type="text" name="genre"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="submit" value="Add"></td>
			</tr>
		</table>
	</form>
</body>
</html>

