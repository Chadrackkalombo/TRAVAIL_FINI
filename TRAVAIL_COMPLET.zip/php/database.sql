create database test;

use test;

CREATE TABLE `etudiant` (
  `id` int(11) NOT NULL auto_increment,
  `nom` varchar(100) NOT NULL,
  `postnom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `promotion` varchar(100) NOT NULL,
  `matricule` varchar(100) NOT NULL,
  `age` int(3) NOT NULL,
  `email` varchar(100) NOT NULL,
  `genre` ENUM('m','f') NOT NULL,
  PRIMARY KEY  (`id`)
);