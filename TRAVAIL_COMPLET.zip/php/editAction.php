<?php
// Include the database connection file
require_once("dbConnection.php");

if (isset($_POST['update'])) {
	// Escape special characters in a string for use in an SQL statement
	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	$nom = mysqli_real_escape_string($mysqli, $_POST['nom']);
	$postnom = mysqli_real_escape_string($mysqli, $_POST['postnom']);
	$prenom = mysqli_real_escape_string($mysqli, $_POST['prenom']);
	$promotion = mysqli_real_escape_string($mysqli, $_POST['promotion']);
	$matricule = mysqli_real_escape_string($mysqli, $_POST['matricule']);
	$age = mysqli_real_escape_string($mysqli, $_POST['age']);
	$email = mysqli_real_escape_string($mysqli, $_POST['email']);
	$genre = mysqli_real_escape_string($mysqli, $_POST['genre']);
	
	// Check for empty fields
	if (empty($nom) || empty($postnom) || empty($prenom) || empty($promotion) || 
	empty($matricule) || empty($age) || empty($email) || empty($genre)) {
		if (empty($nom)) {
			echo "<font color='red'>Le champ Nom est vide.</font><br/>";
		}

		if (empty($postnom)) {
			echo "<font color='red'>Le champ Postom est vide.</font><br/>";
		}

		if (empty($prenom)) {
			echo "<font color='red'>Le champ Prenom est vide.</font><br/>";
		}

		if (empty($promotion)) {
			echo "<font color='red'>Le champ Promotion est vide.</font><br/>";
		}

		if (empty($matricule)) {
			echo "<font color='red'>Le champ Matricule est vide.</font><br/>";
		}
		
		if (empty($age)) {
			echo "<font color='red'>Le Champ Age est vide.</font><br/>";
		}
		
		if (empty($email)) {
			echo "<font color='red'>Le champ Email est vide.</font><br/>";
		}
		
		// Show link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";

	} elseif (strtolower($genre) != 'm' && strtolower($genre) != 'f'){
		echo"<font color='red'>Le Genre doit être soit m pour masculin, soit f pour féminin.</font><br/>";

	} elseif ($age < 16 || $age >59) {
		echo "<font color='red'>L'age que vous avez entré n'est pas correct.</font><br/>";
	
	} else {
		// Update the database table
		$result = mysqli_query($mysqli, "UPDATE etudiant SET `nom` = '$nom', `postnom` = '$postnom', `prenom` = '$prenom', `promotion` = '$promotion',
		`matricule` = '$matricule', `age` = '$age', `email` = '$email', `genre` = '$genre' WHERE `id` = $id");
		
		// Display success message
		echo "<p><font color='green'>Data updated successfully!</p>";
		echo "<a href='index.php'>View Result</a>";
	}
}
