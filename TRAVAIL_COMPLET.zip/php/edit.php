<?php
// Include the database connection file
require_once("dbConnection.php");

// Get id from URL parameter
$id = $_GET['id'];

// Select data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM etudiant WHERE id = $id");

// Fetch the next row of a result set as an associative array
$resultData = mysqli_fetch_assoc($result);

$nom = $resultData['nom'];
$postnom = $resultData['postnom'];
$prenom = $resultData['prenom'];
$promotion = $resultData['promotion'];
$matricule = $resultData['matricule'];
$age = $resultData['age'];
$email = $resultData['email'];
$genre = $resultData['genre']
?>
<html>
<head>	
	<title>Edit Data</title>
</head>

<body>
    <h2>Edit Data</h2>
    <p>
	    <a href="index.php">Home</a>
    </p>
	
	<form name="edit" method="post" action="editAction.php">
		<table border="0">
			<tr> 
				<td>Nom</td>
				<td><input type="text" name="nom" value="<?php echo $nom; ?>"></td>
			</tr>
			<tr> 
				<td>Postnom</td>
				<td><input type="text" name="postnom" value="<?php echo $postnom; ?>"></td>
			</tr>
			<tr> 
				<td>Prenom</td>
				<td><input type="text" name="prenom" value="<?php echo $prenom; ?>"></td>
			</tr>
			<tr> 
				<td>Promotion</td>
				<td><input type="text" name="promotion" value="<?php echo $promotion; ?>"></td>
			</tr>
			<tr> 
				<td>Matricule</td>
				<td><input type="text" name="matricule" value="<?php echo $matricule; ?>"></td>
			</tr>
			<tr> 
				<td>Age</td>
				<td><input type="text" name="age" value="<?php echo $age; ?>"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email" value="<?php echo $email; ?>"></td>
			</tr>
			<tr> 
				<td>Genre</td>
				<td><input type="text" name="genre" value="<?php echo $genre; ?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $id; ?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
